#!/bin/bash

export MONO_PREFIX=/software/mono-2.10-el6-x86_64
export BOOST_PREFIX=/software/boost-1.51-el6-x86_64/lib
export APSIM=$PWD
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MONO_PREFIX/lib:$BOOST_PREFIX:$APSIM/Model
export PATH=$PATH:$APSIM:$APSIM/Model:$APSIM/Files:/software/R-2.15-el6-x86_64/bin:/software/matlab-2012b-x86_64/bin
